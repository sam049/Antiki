import React, {Component} from 'react'

export default class Homepage extends Component {
  constructor() {
    super()
    this.state = {}
  }
  render() {
    console.log('homepage hit')
    console.log(this)
    console.log(this.props)
    return (
      <div>
        <h1>WELCOME TO JEFFREYS TARGET PALACE</h1>
        <p className="paragraph">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin
          ullamcorper et enim ut iaculis. Nunc aliquet gravida imperdiet. Nunc
          urna est, lacinia sit amet tempor sit amet, posuere non lacus. Integer
          arcu mi, vulputate vel massa vitae, hendrerit lacinia orci. Vestibulum
          nec arcu a ipsum fermentum porttitor. Curabitur vitae nunc quis quam
          vestibulum venenatis sit amet quis neque. Nam egestas libero ut dui
          faucibus, vitae malesuada turpis pulvinar. Donec condimentum varius
          tincidunt. Sed et felis sed nunc ornare laoreet non eu nulla. Mauris
          egestas augue nec ex aliquam tristique.
          <br />
          <br />
          Nullam tellus risus, pretium ac feugiat id, tempus eu leo. Vivamus
          bibendum tincidunt nisl, ac porta nisi viverra at. Aliquam erat
          volutpat. Praesent nec congue tellus, et rutrum dolor. Pellentesque a
          enim risus. Curabitur elementum ultrices lacus ac iaculis.
          Pellentesque cursus non metus quis congue.
          <br />
          <br />
          Donec non sapien suscipit erat porta imperdiet. Pellentesque ut elit
          vel arcu volutpat placerat at molestie erat. In nec ipsum ut dui
          bibendum pellentesque sed facilisis est. Morbi sit amet nulla vitae
          neque vestibulum pretium eget sit amet metus. Nunc at urna nibh. Morbi
          non porttitor sapien, nec eleifend leo. Etiam tincidunt nisl ut neque
          sodales, eu egestas leo commodo. Class aptent taciti sociosqu ad
          litora torquent per conubia nostra, per inceptos himenaeos. Quisque
          vel felis nibh. Suspendisse potenti. Proin maximus urna quis sapien
          sagittis venenatis. Phasellus eu turpis arcu. Quisque id facilisis
          neque, nec ultrices risus.
          <br />
          <br />
          Maecenas maximus eros ut blandit accumsan. In a interdum felis, vitae
          consequat magna. Etiam consequat ipsum quis turpis sagittis, sed
          interdum diam maximus. Maecenas vel condimentum dolor. Suspendisse
          vitae posuere magna, eu blandit ante. Donec faucibus eros eget commodo
          tempor. Vestibulum congue finibus leo. Proin nec commodo magna, ut
          efficitur nulla. Suspendisse pharetra mi sit amet lectus rhoncus porta
          a eu velit. Nam ultricies scelerisque orci, id eleifend nisl cursus
          quis. Nullam eget est sed quam ultricies convallis sed et tellus.
          Phasellus vehicula pellentesque nulla cursus dapibus. Integer sed
          velit dui. Suspendisse quis tellus nibh.
          <br />
          <br />
          Mauris vel leo ac lorem commodo pulvinar. Vestibulum aliquam nibh
          commodo mattis vulputate. Proin commodo, magna ut vestibulum commodo,
          lectus leo rutrum leo, at congue eros ipsum vitae magna. Mauris
          efficitur massa purus, in vulputate enim lobortis feugiat. Donec
          vulputate mattis posuere. Aenean imperdiet urna non finibus viverra.
          Duis sagittis pharetra nisl, quis blandit justo pharetra in. Nullam
          elementum orci eu nibh gravida, sed iaculis lectus semper. Nulla
          facilisi. Donec faucibus magna quis leo vehicula scelerisque.
        </p>
      </div>
    )
  }
}
